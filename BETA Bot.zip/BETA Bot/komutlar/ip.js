﻿const Discord = require('discord.js');
exports.run = function(client, message, args) {

  const embed = new Discord.RichEmbed()
  .setColor("BLACK")
  .setTitle('SUNUCU İP')
  .setDescription('**Mars Roleplay İyi Roller Diler.**')
  .addField(`Sunucu Ip Adresimiz`,`**connect 91.151.94.77**`, true)
  .addField(`TeamSpeak 3 Adresimiz`,`**betarp**` , true)
  .setImage('')

  message.channel.send(' ',{embed});
};
exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: ["bakım",],
  permLevel: 0,
  kategori:"genel"
};

exports.help = {
  name: 'ip',
  description: 'Sunucu İp',
  usage: '+ip'
};
