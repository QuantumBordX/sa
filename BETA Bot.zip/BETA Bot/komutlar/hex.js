﻿const Discord = require('discord.js');
exports.run = function(client, message, args) {

  const embed = new Discord.RichEmbed()
  .setColor("WHITE")
  .setTitle('**Hex Adresi Başarıyla Giriş Yapıldı !**')
  .setDescription('connect 91.151.94.77  TS IP - betarp')
  .setImage('')

  message.channel.send('',{embed});
};
exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: ["hex",],
  permLevel: 2,
  kategori:"genel"
};

exports.help = {
  name: 'hex',
  description: 'Hex ID',
  usage: '+hex'
};