﻿const Discord = require('discord.js');
exports.run = function(client, message, args) {

  const embed = new Discord.RichEmbed()
  .setColor("WHITE")
  .setTitle('SUNUCU RESTART')
  .setDescription('**Sunucumuza şu anda ufak bir restart atacaktır lütfen sunucudan çıkış yapınız.**')
  .setImage('')

  message.channel.send('||@everyone|| ||@here||',{embed});
};
exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: ["res",],
  permLevel: 2,
  kategori:"genel"
};

exports.help = {
  name: 'restart',
  description: 'Sunucu Restart Atılacak Komut',
  usage: '+restart'
};