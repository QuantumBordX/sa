﻿const Discord = require('discord.js');
exports.run = function(client, message, args) {

  const embed = new Discord.RichEmbed()
  .setColor("WHITE")
  .setTitle('BETA ROLEPLAY')
  .setDescription('**Destek Sorumlusu Kısa Sürede Size Yardımcı Olacaktır! Beta Roleplay İyi Roller Diler.**')
  .setImage('')

  message.channel.send('|| <@&914926520911401036> ||',{embed});
};
exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: ["bakım",],
  permLevel: 0,
  kategori:"genel"
};

exports.help = {
  name: 'destek',
  description: 'Destek Çağırma Komutu',
  usage: '+destek'
};