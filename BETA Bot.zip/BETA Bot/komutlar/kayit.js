﻿const Discord = require('discord.js');
exports.run = function(client, message, args) {

  const embed = new Discord.RichEmbed()
  .setColor("WHITE")
  .setTitle('**BETA ROLEPLAY**')
  .setDescription('**Kayıt Sorumlusu Kısa Sürede Size Yardımcı Olacaktır! Mars Roleplay İyi Roller Diler.**')
  .setImage('')

  message.channel.send('|| <@&914926521712513026> ||',{embed});
};
exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: ["bakım",],
  permLevel: 0,
  kategori:"genel"
};

exports.help = {
  name: 'kayıt',
  description: 'Kayıt Çağırma Komutu',
  usage: '+kayıt'
};