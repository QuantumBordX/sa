﻿const Discord = require('discord.js');
exports.run = function(client, message, args) {

  const embed = new Discord.RichEmbed()
  .setColor("WHITE")
  .setTitle('SUNUCU AKTİF')
  .setDescription('**Sunucumuz şu anda aktiftir. Giriş Yapabilirsiniz**')
  .addField(`Sunucu Ip Adresimiz`,`**connect 91.151.94.77**`, true)
  .addField(`TeamSpeak 3 Adresimiz`,`**betarp**` , true)
  .setImage('')
  message.channel.send('||@everyone|| ||@here||',{embed});
};
exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: ["online",],
  permLevel: 2,
  kategori:"genel"
};

exports.help = {
  name: 'aktif',
  description: 'Sunucu Aktifse Atılacak Komut',
  usage: '+aktif'
};